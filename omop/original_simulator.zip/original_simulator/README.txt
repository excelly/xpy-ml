#*******************************************************************************
#
#   OSIM_MAIN.R - version 1.1
#
#   Observational Medical Outcomes Partnership
#
#   Procedure for constructing simulated observational datasets
#
#   Original Pseudo Code Design: Patrick Ryan, GlaxoSmithKline
#   Written in R: Rich Murray, ProSanos Corporation
#   Last modified: 10 August 2009
#
#
#	�2009 Foundation for the National Institutes of Health
#
#	(c) 2009 Foundation for the National Institutes of Health (FNIH).
#
#	Licensed under the Apache License, Version 2.0 (the "License"); you may not
#	use this file except in compliance with the License. You may obtain a copy
#	of the License at http://omop.fnih.org/publiclicense.
#
#	Unless required by applicable law or agreed to in writing, software
#	distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#	WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. Any
#	redistributions of this work or any derivative work or modification based on
#	this work should be accompanied by the following source attribution: "This
#	work is based on work by the Observational Medical Outcomes Partnership
#	(OMOP) and used under license from the FNIH at
#	http://omop.fnih.org/publiclicense.
#
#	Any scientific publication that is based on this work should include a
#	reference to http://omop.fnih.org.
#
#   DESCRIPTION:
#
#       OSIM is an automated procedure to construct simulated datasets to 
#       supplement methods evaluation for identifying drug-outcome associations 
#       in observational data sources.  The simulated datasets produced by this 
#       program are modeled after real observational data sources, but are 
#       comprised of hypothetical persons with fictional drug exposure and 
#       health outcomes occurrence. The datasets are constructed such that the 
#       relationships between the fictional drugs and fictional outcomes are 
#       well-characterized as �true� and �false� associations. Hypothetical 
#       persons are created and assigned fictional drug exposure periods and 
#       instances of health outcomes based on random sampling from probability 
#       distributions that define the relationships between the fictional drugs 
#       and outcomes. The relationships created within the simulated datasets 
#       are contrived, but are representative of the types of relationships
#       expected to be observed within real observational data sources.
#
#       To accommodate the efficient and timely generation of a large number of 
#       simulated records using a variety of high performance and lower-end 
#       platforms, the program has been designed for both local and distributed 
#       execution modes.  In local execution mode the Simulation Attribute 
#       Tables, which contain fictional drugs and conditions and the 
#       relationships between them, are generated in the same run as the 
#       Simulated Persons.  In a distributed mode run, the Simulation Attribute 
#       Tables are generated first, in an initial execution.  These Simulation 
#       Attribute Tables are used as input to multiple, distributed executions 
#       of OSIM to generate Simulated Persons.  Since the distributed Simulated 
#       Person Files were generated using the same input Tables, the files can 
#       be concatenated into one large Simulated Person file at the conclusion 
#       of the distributed runs.  
#
#		To allow the simulated dataset to approximate characteristics of real 
#		observational data, preliminary analyses were conducted on an 
#		administrative claims database.  Descriptive statistics were calculated 
#		to estimate the categories and probability distributions parameters for:
#           � Year of Birth
#           � Gender
#           � Race
#           � Observation period duration
#           � Prevalence rate of drug use
#           � Length of drug exposure
#           � Number of periods of exposure	
#           � Prevalence rate of conditions
#           � Number of condition occurrences
#
#		Where data were not available, domain categories and probability 
#		distributions were invented based on past experience.  These attributes 
#		include:
#           � Attributable risk of drug exposure from age
#           � Attributable risk of drug exposure from gender
#           � Attributable risk of drug exposure from race
#           � Attributable risk of drug exposure from �confounder�
#           � Sensitivity of data capture for drug exposure
#           � Specificity of data capture for drug exposure
#           � Proportion of exposure with prior indication
#           � Number of drugs per indication
#           � Attributable risk of condition from age
#           � Attributable risk of condition from gender
#           � Attributable risk of condition from race
#           � Attributable risk of condition from �confounder�
#           � Sensitivity of data capture for condition
#           � Specificity of data capture for condition
#
#		These probability distributions, which are described in detail in the 
#		Data Dictionary for the Observational Medical Dataset Simulator, are 
#		input to OSIM and are used to generate the simulated Attribute Tables 
#		and Persons.
#
#*******************************************************************************
#
#   Contents of this #ReadMe.txt file
#
#    1. System Requirements
#    2. Input Execution Parameter File
#    3. Input Statistical Distributions Parameter File
#    4. INPUT/OUTPUT Simulated Conditions
#    5. INPUT/OUTPUT Simulated Drugs
#    6. INPUT/OUTPUT Simulated Indications
#    7  INPUT/OUTPUT Simulated Drug Outcomes
#    8. INPUT/OUTPUT Simulated Indication Outcomes
#    9. OUTPUT Simulated Persons
#   10. OUTPUT Simulated Observation Periods
#   11. OUTPUT Simulated Drug Exposures
#   12. OUTPUT Simulated Condition Occurrences
#   13.	OUTPUT Runtime Documentation
#   14. Program Control Constants
#   15. Program Execution
#
################################################################################

1. System Requirements:
    R 2.9.0

################################################################################
	
2. Input Execution Parameter File (OSIM_execParms.txt)

    This is a file of Name=Value pairs that control the execution of the 
    program. Any line beginning with the pound (#) character is ignored as a
    comment.
	
    simName          Text      Up to 50 characters, including spaces
     Short handle describing this set of simulation parameters
	 Default:  Observational Simulation Parameters

    simDescription   Text      No character limit
     Longer description of this set of simulation parameters
     Default:  Blank

    personCount      Numeric   1 � 500000000
     Number of simulated Persons to be generated during the program execution
     Default:  5000000

    personStartID    Numeric   1 � 500000000
     The starting PERSON_ID in the simulated data
     Default:  1

    drugCount        Numeric   1 � 99999
     Number of simulated Drugs to be generated during the program execution
     Default:  5000

    conditionCount   Numeric   1 � 99999
     Number of simulated Conditions to be generated during the program execution
     Default:  4000

    minDatabaseDate  Numeric   1900 - 100000 
    The valid range between the min and maxDatabase date is 0-100 years
     Earliest year of observation contained in the generated data
     Default:  2000

    maxDatabaseDate  Numeric   1900 - 100000 
    The valid range between the min and maxDatabase date is 0-100 years
     Latest year of observation contained within the generated data
     Default:  2010

    createSimTables  Boolean   TRUE/FALSE  
     Indicates whether or not to create the Simulation Attribute Tables in this
     run (if �false�, the 5 simulation attribute tables must exist in the 
     specified output directory with the specified file suffix)
     Default:  True

    createSimPersons Boolean   TRUE/FALSE
     Indicates whether or not to create the Simulated Persons files
     Default:  True

    validationMode   Boolean   TRUE/FALSE
     Indicator to set �validation mode� run
     Default: False

    fileModifier     Text
     Unique modifier for output file names and output directory name
     Default:  Current Date/Time Stamp (system assigned)

    fileDistNumber   AlphaNumeric
     Unique modifier for simulate output file names to identify sequential
        file parts in a distributed environment
     Default:  Current personStartID

    ============================================================================
    #Example OSIM_execParms.txt
    simName=Simulated US Patient Data
    simDescription=Patient data modelling a general set of US patients.
    personCount=500
    personStartID=1
    drugCount=5000
    conditionCount=4000
    minDatabaseDate=2000
    maxDatabaseDate=2010
    createSimTables=TRUE
    createSimPersons=TRUE
    validationMode=FALSE
    #fileModifier=OSIM_20090714_111417
    #fileHeader=FALSE
    #fileDistNumber=1
    ============================================================================
	
################################################################################

3. Input Statistical Distributions Parameter File (OSIM_distParms.txt)
	
    This is a tab delimited file containing the standard distributions used by
    the simulation program to model drug, condition, and patient data.
	
    During a createSimTables=TRUE run, the file OSIM_distParms.txt must be in
    the starting working directory with the execution parameter file.  It will 
    be copied to the $FILE_MODIFIER$ directory as 
    OSIM_DISTRIBUTIONS_$FILE_MODIFIER$.txt.
	
    During a createSimPersons=TRUE only run, the copy of the original 
    distribution file, OSIM_DISTRIBUTIONS_$FILE_MODIFIER$.txt, must exist in the
    $FILE_MODIFIER$ directory with the simulated conditions, drugs, indication, 
    indication_outcomes, and drug_outcomes files.
	
    These input probability distributions are used to model baseline 
    characteristics in the simulated data, as well as confounding factors that 
    can influence the assessment of an exposure or an outcome.  There are 31 
    different probability distributions contained within the file, specified by 
    the first (DistName) column.
	
    Each distribution contains a series of categories describing a particular 
    data characteristic with a probability assigned to each category.  Simulated
    data are generated by sampling from a multinomial distribution based on the 
    specified probabilities within each distribution.  
	
    In addition to generating simulated data by sampling from the probability 
    distribution categories, many of the distributions include an additional 
    Sampling Rule, which defines how a specific value is selected from within 
    the sampled category (for instance, selecting an age within the 0-10 age 
    range category).  There are six standard Sampling Rules included in the OSIM
    program, each requiring a fixed set of from 1-4 parameters that must be 
    provided in order to calculate the additional values.  The probabilities for
    all categories within a particular distribution can be modified by the user 
    from their default values, but they must add up to 1.  In addition, with the
    exception of three probability distributions, the default category names can
    be modified by the user.  The three distributions with category names that 
    can not be modified are Person Gender Recorded, Person Race Recorded, and 
    Person Age Recorded.  If the category names for the age, gender, race, and 
    confounder distributions are changed, care must be taken to ensure that 
    the associated Sampling Rules for calculating age, gender, race, and 
    confounder attributable risk are modified to reflect the new category 
    values. The standard Sampling Rules and associated parameters are described 
    below:
	
    unif (Uniform Distribution) returns a uniform sample between Lower and Upper
	
    norm (Truncated Normal Distribution) returns a normal distribution sample 
        with the specified Mean and StDev between Lower and Upper

    const (Constant) returns the value in the Constant column
	
    cont (Continuous Variable Sampling Function) returns the test value 
        multiplied by the optional Factor and the optional BP (Baseline 
        Prevalence) column if the test value is greater than or equal to the 
        optional minCut column and less than or equal to the optional maxCut 
        column

    cat (Category Match) returns a uniform sample between the Lower and Upper 
        columns multiplied by the option the BP (Baseline Prevalence) column if 
        the optional Category column matches the passed in Category

    duration (Duration Distribution) used to sample from a uniform distribution 
	    that is the length of the drug exposure to determine the onset of an 
		outcome, for "insidious onset" drugs.

    omit (remove from output) only applies to DrugConfounderRisk and 
        IndOutcomeAttrRisk DistNames to remove unassigned pairs from the 
        OSIM_DRUGOUTCOME and OSIM_INDOUTCOME output files.
	
    The standard distributions (DistName) that must be present are:
    
        PersonAge - multinomial age range buckets, each with individual age 
            sample rules

        PersonAgeRecorded - two multinomial buckets with a constant of 1 or 0
            indicating whether the simulated person age should be recorded

        PersonGender - multinomial gender assignment with no further rules

        PersonGenderRecorded - two multinomial buckets with a constant of 1 or 0
            indicating whether the simulated person gender should be recorded

        PersonRace - multinomial gender assignment with no further rules applied

        PersonRaceRecorded - two multinomial buckets with a constant of 1 or 0
            indicating whether the simulated person gender should be recorded
            
        PersonConfounder - two multinomial buckets with a constant of 1 or 0
            indicating whether the simulated person has confounder

        PersonAgeAtDeath - a single bucket with the sampling rule for 
            determining age of death

        ObservationPeriod - multinomial observation period range buckets, each 
            with individual sample rules

        CondBaselinePrevalence - multinomial prevalence range buckets, each with 
            individual sample rules

        CondAttrRiskAge - multinomial age risk buckets with cont and cat rules 
            to assign additional age risk to a condition occurrence

        CondAttrRiskGender - multinomial gender risk buckets with cont and cat 
            rules to assign additional gender risk to a condition occurrence

        CondAttrRiskRace - multinomial race risk buckets with cont and cat rules 
            to assign additional race risk to a condition occurrence

        CondConfounderRisk - multinomial race confounder buckets with cont and 
            cat rules to assign additional confounder risk to a condition 
            occurrence

        CondSensitivity - multinomial sensitivitiy range buckets to assign the 
            probability of a condition occurrence being recorded

        CondSpecificity - multinomial specificity range buckets to assign the 
            probability of a condition occurrence being falsely recorded

        CondOccurrence - multinomial number of occurrence buckets to categorize 
            a condition and assign the number simulated condition occurrences

        DrugBaselinePrevalence - multinomial prevalence range buckets, each with 
            individual sample rules

        DrugAttrRiskAge - multinomial age risk buckets with cont and cat rules 
            to assign additional age risk to a drug exposure

        DrugAttrRiskGender - multinomial gender risk buckets with cont and cat 
            rules to assign additional gender risk to a drug exposure

        DrugAttrRiskRace - multinomial race risk buckets with cont and cat rules
            to assign additional race risk to a drug exposure

        DrugConfounderRisk - multinomial race confounder buckets with cont and 
            cat rules to assign additional confounder risk to a drug occurrence

        DrugSensitivity - multinomial sensitivitiy range buckets to assign the 
            probability of a drug occurrence being recorded

        DrugSpecificity - multinomial specificity range buckets to assign the 
            probability of a drug occurrence being falsely recorded

        DrugExposureLength - multinomial duration buckets to assign an exposure 
            duration to a drug exposure

        DrugNumExposures - multinomial number of occurrence buckets to 
            categorize a drug and assign the number of times a simulated drug 
            exposure occurs

        DrugPriorIndication - multinomial probability buckets to assign an 
            association between drugs and indications

        DrugsPerIndication - multinomial range buckets to determine the number 
            of drugs to which an indication should be associated

        IndOutcomeAttrRisk - multinomial number of outcome buckets to assign the
            number of outcomes to which an indication should be associated

        IndStartDate - multinomial number of time duration buckets to assign the
            start date of an indication relative to the first drug exposure date

        DrugOutcomeRiskType - multinomial outcome buckets to assign 
            the type of effect of a drug exposure has on an outcome (may be 
            preventative, constant rate, constant risk, or no effect)

        DrugOutcomeConstantRiskAttrRisk - multinomial buckets for categorizing 
            and assigning attributable drug risk effect to "Constant risk" drug 
            outcomes

        DrugOutcomeConstantRateAttrRisk - multinomial buckets for categorizing 
            and assigning attributable drug risk effect to "Constant rate" drug 
            outcomes

        DrugOutcomeConstantRiskOnset - multinomial time range buckets to assign 
            the delay of time (in days) between the exposure to a drug and the 
            onset of the constant risk outcome

        DrugOutcomeConstantRateOnset - multinomial time range buckets to assign 
            the delay of time (in days) between the exposure to a drug and the 
            onset of the constant rate outcome

        More detail on the distribution parameters can be found in the data 
        dictionary.

################################################################################

4. INPUT/OUTPUT Simulated Conditions (OSIM_CONDITIONS_$FILE_MODIFIER$)

    This is a tab delimited file of simulated conditions from a 
    createSimTables=TRUE run, where it will be created in the $FILE_MODIFIER$ 
    subdirectory of the current working directory.
	
    This file is input to a createSimPersons=TRUE run.

################################################################################

5. INPUT/OUTPUT Simulated Drugs 
    (OSIM_DRUGS_$FILE_MODIFIER$.txt)

    This is a tab delimited file of simulated conditions from a 
    createSimTables=TRUE run, where it will be created in the $FILE_MODIFIER$ 
    subdirectory of the current working directory.
	
    This file is input to a createSimPersons=TRUE run.

################################################################################

6. INPUT/OUTPUT Simulated Indications 
    (OSIM_INDICATIONS_$FILE_MODIFIER$.txt)

    This is a tab delimited file of simulated indications (associated to
    simulated conditions) from a createSimTables=TRUE run, where it will be 
    created in the $FILE_MODIFIER$ subdirectory of the current working directory.
	
    This file is input to a createSimPersons=TRUE run.

###############################################################################

7. INPUT/OUTPUT Simulated Drug Outcomes 
    (OSIM_DRUG_OUTCOMES_$FILE_MODIFIER$.txt)

    This is a tab delimited file of associated drugs and outcome conditions 
    from a createSimTables=TRUE run, where it will be created in the 
    $FILE_MODIFIER$ subdirectory of the current working directory.
	
    This file is input to a createSimPersons=TRUE run.

################################################################################

8. INPUT/OUTPUT Simulated Indication Outcomes 
    (OSIM_INDICATION_OUTCOMES_$FILE_MODIFIER$.txt)

    This is a tab delimited file of associated indication and outcome 
    conditions  from a createSimTables=TRUE run, where it will be created in the
    $FILE_MODIFIER$ subdirectory of the current working directory.
    
    This file is input to a createSimPersons=TRUE run.

################################################################################
	
9. OUTPUT Simulated Persons 
    (OSIM_PERSON_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    This is a tab delimited file in CDM format of simulated persons from a
    createSimTables=TRUE run.
	
    If the program is running in validationMode=TRUE mode, then an even more
    detailed version of this file is produced named:
        OSIM_PERSON_VALID_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)
		
    The validation file contains assigned risk values as well as values that may 
    be masked from the actual output due to recording probabilities.

################################################################################

10. OUTPUT Simulated Observation Periods 
    (OSIM_OBSERVATION_PERIOD_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    This is a tab delimited file in CDM format of simulated observation periods
    for each simulated person from a createSimTables=TRUE run.  In this current 
    implementation, only a single observation period is produced per simulated 
    person.
	
    If the program is running in validationMode=TRUE mode, then an even more
    detailed version of this file is produced named:
        OSIM_OBSERVATION_PERIOD_VALID_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    The validation file contains assigned sample risk values as well as values 
    that may be masked from the actual output due to recording probabilities.

################################################################################

11. OUTPUT Simulated Drug Exposures 
    (OSIM_DRUG_EXPOSURE_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    This is a tab delimited file in CDM format of simulated drug exposures from
    a createSimTables=TRUE run.
	
    If the program is running in validationMode=TRUE mode, then an even more
    detailed version of this file is produced named:
        OSIM_DRUG_EXPOSURE_VALID_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    The validation file contains assigned risk values as well as values that may 
    be masked from the actual output due to recording probabilities.

################################################################################

12. OUTPUT Simulated Condition Occurrences 
    (OSIM_CONDITION_OCCURRENCE_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    This is a tab delimited file in CDM format of simulated condition
    occurrences from a createSimTables=TRUE run.
	
    If the program is running in validationMode=TRUE mode, then an even more
    detailed version of this file is produced named:
        OSIM_DCONDITION_OCCURRENCE_VALID_$FILE_MODIFIER$_$FILE_DIST_NUM$.txt)

    The validation file contains assigned risk values as well as values that may 
    be masked from the actual output due to recording probabilities.

################################################################################

13.	OUTPUT Runtime Documentation 
    (OSIM_DOCUMENTATION_$FILE_MODIFIER$.txt)

    This documentation file is appended with various timestamped messages
    during the simulator execution.

################################################################################

14. Program Control Constants

    A few contants and control variables are set at the beginning of the 
    program to allow easy future modification.  They include all the core 
    filenames.
	
    OSIM.CONDITIONS.FILENAME <- "OSIM_CONDITIONS"
    OSIM.DRUGS.FILENAME <- "OSIM_DRUGS"
    OSIM.INDICATIONS.FILENAME <- "OSIM_INDICATIONS"
    OSIM.DRUGOUTCOME.FILENAME <- "OSIM_DRUG_OUTCOMES"
    OSIM.INDOUTCOME.FILENAME <- "OSIM_INDICATION_OUTCOMES"

    OSIM.DISTRIBUTION.FILENAME <- "OSIM_DISTRIBUTIONS"
    OSIM.INPUT.PARMS.FILENAME <- "OSIM_execParms"
    OSIM.INPUT.DISTRIBUTION.FILENAME <- "OSIM_distParms"

    OSIM.RUNLOG.FILENAME <- "OSIM_DOCUMENTATION"
	
    OSIM.PERSONS.FILENAME <- "OSIM_PERSON"
    OSIM.OBSERVATIONS.FILENAME <- "OSIM_OBSERVATION_PERIOD"
    OSIM.DRUGEXPOSURE.FILENAME <- "OSIM_DRUG_EXPOSURE"
    OSIM.CONDITIONOCCURRENCE.FILENAME <- "OSIM_CONDITION_OCCURRENCE"

	
    The Date Format to write to CDM output files:

    OSIM.CDM.DATE.FORMAT <- "%Y-%m-%d"	# ISO 8601

	
    CDM ID Codes:

    OSIM.CDM.GENDER.CODES <- factor(c("Male" = 8507, "Female" = 8532))
    OSIM.CDM.RACE.CODES <- factor(c("White" = 8527, "Non-white" = 9178))
    OSIM.CDM.STATUS.CODES <- factor(c("active" = 9181, "deceased" = 9176))
	
	
    A constant to control the maximium rows in a data.frame in memory:
	
    MAX.DATAFRAME.SIZE <- 1000000
	
    A constant to initialize the random generator in validation mode:

    OSIM.VALIDATION.SEED <- 31
	
################################################################################

15. Program Execution:
    From RGui
        setwd("$INPUT_FILE_PATH$")
        source("$PROGRAM_SOURCE_PATH$/OSIM_MAIN.R")
        main()

        The execution parameter file must exist in the working directory.  The 
        distribution parameter file must either exist in the working directory
        (for a createSimTables=TRUE run) or its copy must exist in the 
        fileModifier subdirectory (for a createSimPersons=TRUE run) along with 
        the conditions, drugs, indications, drug outcomes, and indication 
        outcomes files.
		
		
	Batch Mode
        For running in batch mode, the program will need to be altered as
        follows: 
        At the very end of the source, the main() function definition will need 
        to eliminated so its content is executed when the source is loaded.
	
        #main <- function() {
            getExecParms()
            if (validationMode) { set.seed(OSIM.VALIDATION.SEED) }
            if (createSimTables) { OSIM.Module1() }
            if (createSimPersons) { OSIM.Module2() }
            logMessage("Processing Complete")
        #}

        Change the working directory to $INPUT_FILE_PATH$

        The execution parameter file must exist in the working directory.  The 
        distribution parameter file must either exist in the working directory
        (for a createSimTables=TRUE run) or its copy must exist in the 
        fileModifier subdirectory (for a createSimPersons=TRUE run) along with 
        the conditions, drugs, indications, drug outcomes, and indication 
        outcomes files.

        And finally, batch execute the program:
            R CMD BATCH $PROGRAM_SOURCE_PATH$/OSIM_MAIN.R		

    Distributed Mode
        In addition to the changes for Batch mode above:
		
        Distributed mode runs are most likely to be createSimPersons=TRUE runs 
        with createSimTables=FALSE.
	
        Typically, a batch shell script will need to be constructed to change 
        the working directory and issue the R CMD BATCH command on the 
        distributed server.

        The input execution parameter file must exist in startup working 
        directory.

        The copy of the distribution parameter file created in the 
        createSimPersons=TRUE run and all the other sim table files (conditions,
        drugs, indications, drug outcomes, and indication outcomes) must exist 
        in the fileModifier subdirectory of the current working directory prior 
        to execution.

        The execution parameters will need to be modified for each distributed 
        set. The initial set of person output should have fileHeader=TRUE, and 
        all other distributed sets should have fileHeader=FALSE to allow simple 
        file concatenation to reassemble the output.

        The personStartID and personCount parameters should be set to generate 
        unique ranges of personIDs in each distributed run.

        Example (3 sets of 100000 persons to create a 300000 final set)
        ========================================================================
        Distributed Set One execution parameters:
        -------------------------------------------------
        personCount=100000
        personStartID=1
        minDatabaseDate=2000
        maxDatabaseDate=2010
        createSimTables=FALSE
        createSimPersons=TRUE
        validationMode=FALSE
        fileModifier=OSIM_20090714_111417
        fileHeader=TRUE
        #fileDistNumber=1 (will default to starting personID)

        Distributed Set Two execution parameters:
        -------------------------------------------------
        personCount=100000
        personStartID=100001
        minDatabaseDate=2000
        maxDatabaseDate=2010
        createSimTables=FALSE
        createSimPersons=TRUE
        validationMode=FALSE
        fileModifier=OSIM_20090714_111417
        fileHeader=FALSE
        #fileDistNumber=1 (will default to personStartID)
	
        Distributed Set Three execution parameters:
        -------------------------------------------------
        personCount=100000
        personStartID=200001
        minDatabaseDate=2000
        maxDatabaseDate=2010
        createSimTables=FALSE
        createSimPersons=TRUE
        validationMode=FALSE
        fileModifier=OSIM_20090714_111417
        fileHeader=FALSE
        #fileDistNumber=1 (will default to personStartID)

        The output files can simply be concatenated together sequenced by the 
        fileModifer at the end of each file name (though it may only be 
        important to have the initial set of files with headers first).

        OSIM_PERSON_20090714_111417_1.txt
        OSIM_PERSON_20090714_111417_100001.txt
        OSIM_PERSON_20090714_111417_200001.txt


